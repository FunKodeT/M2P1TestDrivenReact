import './locale/il8n'
// import il8n from 'il8next'
// import { initReactIl8next } from 'react-il8next'

// il8n.use(initReactIl8next).init({
// 	resources: { 
// 		en: { 
// 			translation: { 
// 				signUp: 'Sign Up',
// 				username: 'Username',
// 				email: 'Email',
// 				password: 'Password',
// 				passwordRepeated: 'Password Repeated'
// 			}
// 		},
// 		tr: { 
// 			translation: { 
// 				signUp: 'Kayit Ol',
// 				username: 'Kullanici Adi',
// 				email: 'Eposta'
// 				password: '$ifre',
// 				passwordRepeat: '$ifre Tekrari'
// 			}
// 		},
// 	}, 
// 	// lng: 'tr', 
// 	lng: 'en', 
// 	fallbacking: 'en', 
// 	interpolation: { 
// 		escapeValue: false 
// 	} 
// })