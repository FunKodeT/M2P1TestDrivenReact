import SignUpPage from './pages/SignUpPage'

function App() {
	return(
		<div className='container'>
			<SignUpPage />
		</div>
	)
}

export default App